const { start } = require("@progress/kendo-react-dateinputs")

react start

C:\dev\node-v20.11.1-win-x64\yarn install
C:\dev\node-v20.11.1-win-x64\yarn run start


나는 veltix 프레임워크로 react 개발중인데 여기에 MDBDataTable 이 있는데 Show entries를 테이블 아래로 내리싶어

yarn create react-app do-it-example --scripts-version 2.1.7
출처: https://parkjh7764.tistory.com/98 [HwanE Develop Blog:티스토리]

yarn create create-react-app --scripts-version 5.0.1 

.1.7  create-react-app@5.0.1   