import React, { useState } from "react";
import ReactDOM from 'react-dom/client';
import PropTypes, { element } from "prop-types"
import Slider from './Slider';

import styled from 'styled-components';
import { connect } from "react-redux"
import {
  changeLayout,
  changeLayoutWidth,
  changeSidebarTheme,
  changeBodyTheme,
  changeSidebarType,
  changeTopbarTheme,
  showRightSidebarAction,
} from "../../store/actions"

//SimpleBar
import SimpleBar from "simplebar-react"

import { Link } from "react-router-dom"

//Import images
import layout1 from "../../assets/images/layouts/layout-1.jpg"
import layout2 from "../../assets/images/layouts/layout-2.jpg"
import layout3 from "../../assets/images/layouts/layout-3.jpg"

const zoomIn = () => {
  //document.body.style.zoom = `${130}%`;

  document.body.style.zoom = `${150}%`;
}
const zoom = () => {
  document.body.style.zoom = `${100}%`;
}
const zoomOut = () => {
  document.body.style.zoom = `${80}%`;
}

const sizeBig = () => {
  document.body.style.fontSize = '2em';
}
const size = () => {
  document.body.style.fontSize = '1em';
}
const sizeSmall = () => {
  //const currentFontSize = parseInt(document.body.style.fontSize);
  //alert(currentFontSize);
  document.body.style.fontSize = '0.5em';
}

const RightSidebar = props => {
  return (
    <React.Fragment>
      <div className="right-bar" id="right-bar">
        <SimpleBar style={{ height: "900px" }}>
          <div data-simplebar className="h-100">
            <div className="rightbar-title px-3 py-4">
              <Link
                to="#"
                onClick={e => {
                  e.preventDefault()
                  props.showRightSidebarAction(false)
                }}
                className="right-bar-toggle float-end"
              >
                <i className="mdi mdi-close noti-icon" />
              </Link>
              <h5 className="m-0">Settings!!!!</h5>
            </div>

            <hr className="my-0" />

            <div className="p-4">
              <div className="radio-toolbar">
                <span className="mb-2 d-block" id="radio-title">Layouts</span>
                <input
                  type="radio"
                  id="radioVertical"
                  name="radioFruit"
                  value="vertical"
                  checked={props.layoutType === "vertical"}
                  onChange={e => {
                    if (e.target.checked) {
                      props.changeLayout(e.target.value)
                    }
                  }}
                />
                <label htmlFor="radioVertical">Vertical</label>
                {"   "}
                <input
                  type="radio"
                  id="radioHorizontal"
                  name="radioFruit"
                  value="horizontal"
                  checked={props.layoutType === "horizontal"}
                  onChange={e => {
                    if (e.target.checked) {
                      props.changeLayout(e.target.value)
                    }
                  }}
                />
                <label htmlFor="radioHorizontal">Horizontal</label>
              </div>

        <div>
            <button onClick={zoomIn}>확대</button>
            <button onClick={zoom}>현재</button>
            <button onClick={zoomOut}>축소</button>
        </div>

        <div>
            <button onClick={sizeBig}>크게</button>
            <button onClick={size}>현재</button>
            <button onClick={sizeSmall}>작게</button>
        </div>

              <hr className="mt-1" />

              <div className="radio-toolbar">
                <span className="mb-2 d-block" id="radio-title">
                  Zoom Size
                </span>
                <input
                  type="radio"
                  id="radioFluid"
                  name="radioWidth"
                  value="작게"
                  checked={props.layoutWidth === "작게"}
                  onChange={e => {
                    if (e.target.checked) {
                      props.changeLayoutWidth(e.target.value)
                    }
                  }}
                />{" "}
                <label htmlFor="radioFluid">작게</label>
                {"   "}
                <input
                  type="radio"
                  id="radioBoxed"
                  name="radioWidth"
                  value="크게"
                  checked={props.layoutWidth === "크게"}
                  onChange={e => {
                    if (e.target.checked) {
                      props.changeLayoutWidth(e.target.value)
                    //  {zoomOut}
                    }
                  }}
                />{" "}
                <label htmlFor="radioBoxed">크게</label>
              </div>
              <hr className="mt-1" />

             {/*  {props.layoutType === "vertical" ? (
                <React.Fragment>
                  <hr className="mt-1" />
                

                  
                </React.Fragment>
              ) : null} */}
            <hr className="mt-1"></hr>
              <div className="radio-toolbar">
                <span className="mb-2 d-block" id="radio-title">
                  Font Size
                </span>
                <input
                  type="radio"
                  id="radioFluid"
                  name="radioWidth"
                  value="작게"
                  checked={props.layoutWidth === "작게"}
                  onChange={e => {
                    if (e.target.checked) {
                      {zoomOut}
                    }
                  }}
                />{" "}
                <label htmlFor="radioFluid">작게</label>
                {"   "}
                <input
                  type="radio"
                  id="radioBoxed"
                  name="radioWidth"
                  value="크게"
                  checked={props.layoutWidth === "크게"}
                  onChange={e => {
                    if (e.target.checked) {
                     // props.changeLayoutWidth(e.target.value)
                      {zoomIn}
                    }
                  }}
                />{" "}
                <label htmlFor="radioBoxed">크게</label>
              </div>


              <hr className="my-0" />     
              <div className="mb-1">
              <div className="radio-toolbar">
                <span className="mb-2 d-block">Layouts</span>
               
                <input
                  type="radio"
                  id="light-mode-switch"
                  name="radioBloom"
                  value="light"
                  checked={props.layoutType === "light"}
                  onChange={e => {
                    if (e.target.checked) {
                      props.changeBodyTheme(e.target.value)
                    }
                  }}
                />{" "}
                 <label htmlFor="light-mode-switch">light</label>
                 {"   "}
                 <input
                  type="radio"
                  id="dark-mode-switch"
                  name="radioBloom"
                  value="dark"
                  checked={props.layoutType === "dark"}
                  onChange={e => {
                    if (e.target.checked) {
                      props.changeBodyTheme(e.target.value)
                    }
                  }}
                />{" "}
                <label htmlFor="dark-mode-switch">dark</label>
              </div>
              {props.layoutType === "light" ? (
                <React.Fragment>
                  <hr className="mt-1" />
                

                  
                </React.Fragment>
              ) : null}
              <hr className="mt-1" />
            </div>
          </div>
          
          </div>
          </SimpleBar>
      </div>
<div className="RightSidebar">
<Slider/>
</div>



      <div className="rightbar-overlay" />
    </React.Fragment>
  )
}

RightSidebar.propTypes = {
  changeLayout: PropTypes.func,
  changeLayoutWidth: PropTypes.func,
  changeSidebarTheme: PropTypes.func,
  changeBodyTheme: PropTypes.func,
  changeSidebarType: PropTypes.func,
  changeTopbarTheme: PropTypes.func,
  layoutType: PropTypes.any,
  layoutWidth: PropTypes.any,
  leftSideBarTheme: PropTypes.any,
  leftSideBarType: PropTypes.any,
  showRightSidebarAction: PropTypes.func,
  topbarTheme: PropTypes.any,
}

const mapStateToProps = state => {
  return { ...state.Layout }
}

export default connect(mapStateToProps, {
  changeLayout,
  changeSidebarTheme,
  changeBodyTheme,
  changeSidebarType,
  changeLayoutWidth,
  changeTopbarTheme,
  showRightSidebarAction,
})(RightSidebar)
