import React, {useState} from 'react';


const ZoomButton =() =>{

    const [zoomLevel, setZoomLevel] = useState(100);
    const zoomIn = () => {
        document.body.style.zoom = '${130}%';

    }
    const zoomOut = () => {
        document.body.style.zoom = '${100}%';
    }

    const sizeBig = () => {
        document.body.style.fontSize = '${130}%';

    }
    const sizeSmall = () => {
        document.body.style.fontSize = '${100}%';
    }

    return(
        <>
        <div>
            <button onClick={zoomIn}>축소</button>
            <button onClick={zoomOut}>확대</button>
        </div>
        </>
    )
}
export default ZoomButton;