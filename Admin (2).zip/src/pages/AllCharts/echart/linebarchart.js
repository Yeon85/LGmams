import React, { Component } from 'react';
import ReactEcharts from 'echarts-for-react';

class LineBar extends Component {
    getOption = () => {
        return {
            series: [
                {
                    name: '역량Level(23년)',
                    type: 'bar',
                    data: [0, 0, 4, 3, 5, 2, 1, 3]
                },
                {
                    name: '역량Level(24년)',
                    type: 'bar',
                    data: [1, 5, 4, 2.4, 2.7, 3, 1,3]
                },
                {
                    name: '역량평균(23년)',
                    type: 'line',
                    yAxisIndex: 1,
                    data: [2.0, 2.2, 3.3, 4.5, 6.3, 3.3, 2.3, 3.4]
                }
                ,{
                    name: '역량평균(24년)',
                    type: 'line',
                    yAxisIndex: 1,
                    data: [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
                }
            ],
            grid: {
                zlevel: 0,
                x: 50,
                x2: 50,
                y: 30,
                y2: 30,
                borderWidth: 0,
                backgroundColor: 'rgba(0,0,0,0)',
                borderColor: 'rgba(0,0,0,0)',
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#999'
                    }
                }
            },
           
            color: ['#3c4ccf', '#02a499', '#38a4f8','#A50034'],
            legend: {
                data: ['역량Level(23년)', '역량Level(24년)', 'Average temperature'],
                textStyle: {
                    color: ['#74788d']
                }
            },
            xAxis: [
                {
                    type: 'category',
                    data: ['박진권', '권민호', '방정환', '이민섭', '김영호', '김동준', '송근주', '김윤호'],
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                   // name: 'Water volume',
                    min: 0,
                    max: 7,
                    interval: 0.5,
                    axisLabel: {
                        formatter: '{value} ml'
                    },
                    axisLine: {
                        lineStyle: {
                            color: "#74788d"
                        }
                    }
                },
                
                {
                 //   type: 'value',
                    name: '',
                    min: 0,
                   // max: 25,
                   // interval: 5,
                    //axisLabel: {
                    //    formatter: '{value} °C'
                    //}
                }
            ],
        };
    };
    render() {
        return (
            <React.Fragment>
                <ReactEcharts style={{ height: "350px" }} option={this.getOption()} />
            </React.Fragment>
        );
    }
}
export default LineBar;

