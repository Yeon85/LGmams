import React, { Component } from "react";
//import { BarChart } from '@toast-ui/chart';

import BarChart from '@toast-ui/chart';


//import '@toast-ui/chart/dist/toastui-chart.css';
//import '@toast-ui/chart/dist/toastui-chart.min.css';

class tui_barchart extends Component {
  render() {
    var barChartData = {


      categories: ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      series: [
        {
            name: 'Budget',
            data: [5000, 3000, 5000, 7000, 6000, 4000, 1000],
          },
          {
            name: 'Income',
            data: [8000, 4000, 7000, 2000, 6000, 3000, 5000],
          },
      ]
    };
    var barChartOptions = {
      stackBars: true,
      style: 'stroke-width: 30px',
      axisY: {
        labelInterpolationFnc: function(value) {
          return value / 1000 + "k";
        }
      }
    };
    return (
      <React.Fragment>
        <BarChart
          data={barChartData}
          style={{ height: "300px" }}
          options={barChartOptions}
          type={"Bar"}
        />
      </React.Fragment>
    );
  }
}

export default tui_barchart;
