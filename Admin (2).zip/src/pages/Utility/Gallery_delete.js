import React, { useCallback, useState } from "react";
import { useDropzone } from 'react-dropzone';

import {
  Row,
  Col,
  Card,
  CardBody,
  CardTitle,
  CardText,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Container,
} from "reactstrap";
import { connect } from "react-redux";
import { Map, InfoWindow, GoogleApiWrapper } from "google-maps-react";
//Lightbox
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";
import ModalVideo from "react-modal-video";
import "react-modal-video/scss/modal-video.scss";

//Side Effect
import { Slide } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'

// import image
import img1 from "../../assets/images/small/img-1.jpg";
import img2 from "../../assets/images/small/img-2.jpg";
import img3 from "../../assets/images/small/img-3.jpg";
import img4 from "../../assets/images/small/img-4.jpg";
import img5 from "../../assets/images/small/img-5.jpg";
import img6 from "../../assets/images/small/img-6.jpg";
import img7 from "../../assets/images/small/img-7.jpg";

//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb";




const images = [img1, img2, img3, img4, img5, img6];
const zoomImages = [img3, img7];

const LoadingContainer = () => <div>Loading...</div>;

const UiLightbox = (props) => {
  const selectedPlace = {};

  const [photoIndex, setphotoIndex] = useState(0);
  const [isFits, setisFits] = useState(false);
  const [isEffects, setisEffects] = useState(false);
  const [isGallery, setisGallery] = useState(false);
  const [isGalleryZoom, setisGalleryZoom] = useState(false);
  const [isOpen, setisOpen] = useState(false);
  const [isOpen1, setisOpen1] = useState(false);
  const [modal, setmodal] = useState(false);
  const [map, setMap] = useState(false);
  function tog_map() {
    setMap(!map);
  }

  
const [isImageMoved, setIsImageMoved] = useState(false);

const handleButtonClick = () => {
  setIsImageMoved(true);
};


const [imagePositions, setImagePositions] = useState([0, 0]);

const handleButtonsClick = () => {
  setImagePositions([imagePositions[0] - 100, imagePositions[1] - 100]);
};


  const spanStyle = {
    padding: '20px',
    background: '#efefef',
    color: '#000000'
  }

const divStyle = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundSize: 'cover',
  height: '400px'
}
const slideImages = [
  {
    url: 'https://images.unsplash.com/photo-1509721434272-b79147e0e708?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1500&q=80',
    caption: 'Slide 1'
  },
  {
    url: 'https://images.unsplash.com/photo-1506710507565-203b9f24669b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1536&q=80',
    caption: 'Slide 2'
  },
  {
    url: 'https://images.unsplash.com/photo-1536987333706-fc9adfb10d91?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1500&q=80',
    caption: 'Slide 3'
  },
];

function slideImagesMove(value){

  alert(value);

}

const [files, setFiles] = useState([]);
const [disableClick, setDisableClick] = useState(false);
const onDrop = useCallback((acceptedFiles) => {
  setFiles([...files, ...acceptedFiles]);
}, [files]);

const deleteFile = (index) => {
  setFiles(files.filter((file, i) => i !== index)); 
  /*  const updatedFiles = [...files];
   updatedFiles.splice(index, 1);
    setFiles(updatedFiles);
    setDisableClick(false); */
  };

const deleteFiles = () => {
  const updatedFiles = files.filter((file, index) => !file.checked);
  setFiles(updatedFiles);
};
//체크박스 선택시
const handleCheckboxChange = (index) => {
  const updatedFiles = [...files];
  updatedFiles[index].checked = !updatedFiles[index].checked;
  setFiles(updatedFiles);
  setDisableClick(updatedFiles.some((file) => file.checked)); // 체크된 파일이 있는 경우에만 클릭 비활성화
};

const { getRootProps, getInputProps, isDragActive } = useDropzone({
  onDrop,
  noClick: disableClick, // disableClick 값에 따라 클릭 활성화/비활성화 설정
});

//파일업로드 버튼1
const openFileDialog = () => {
  alert(1);
  const input = document.createElement('input');
  alert(2);
  input.type = 'file';
  alert(3);
  input.accept = 'image/*';
  alert(4);
  input.multiple = true; // 여러 개의 파일 선택 가능
  input.onchange = handleImageUpload;
  input.click();
};

//파일업로드 버튼2
const handleImageUpload = (event) => {
  const selectedFiles = Array.from(event.target.files);
  setFiles([...files, ...selectedFiles]);
};

const [images, setImages] = useState([
/*   'image1.jpg',
  'image2.jpg',
  'image3.jpg' */
  // 이 부분에 실제 이미지 경로를 넣어주세요.
]);
const [movedImages, setMovedImages] = useState([]);

/* const moveImages = () => {
  setMovedImages(images);
  setImages([]);
}; */


const moveImages = () => {
  const updatedFiles = files.filter((file, index) => !file.checked);
  setMovedImages(images);
  slideImagesMove(updatedFiles);
};

  document.title = "LG | 반성회 이미지 관리";
  return (
    <React.Fragment>
    
      <div className="page-content">
        <Container fluid={true}>
          <Breadcrumbs maintitle="자율운영" title="작업시간준수" breadcrumbItem="반성회 이미지 관리" />

          {isFits ? (
            <Lightbox
              mainSrc={images[1]}
              enableZoom={false}
              imageCaption={
                "Caption. Can be aligned it to any side and contain any HTML."
              }
              onCloseRequest={() => {
                setisFits(!isFits);
              }}
            />
          ) : null}

          {isEffects ? (
            <Lightbox
              mainSrc={images[2]}
              enableZoom={false}
              onCloseRequest={() => {
                setisEffects(!isEffects);
              }}
            />
          ) : null}

          {isGallery ? (
            <Lightbox
              mainSrc={images[photoIndex]}
              nextSrc={images[(photoIndex + 1) % images.length]}
              prevSrc={images[(photoIndex + images.length - 1) % images.length]}
              enableZoom={true}
              onCloseRequest={() => {
                setisGallery(false);
              }}
              onMovePrevRequest={() => {
                setphotoIndex((photoIndex + images.length - 1) % images.length);
              }}
              onMoveNextRequest={() => {
                setphotoIndex((photoIndex + 1) % images.length);
              }}
              imageCaption={"Project " + parseFloat(photoIndex + 1)}
            />
          ) : null}

          {isGalleryZoom ? (
            <Lightbox
              mainSrc={zoomImages[photoIndex]}
              nextSrc={zoomImages[(photoIndex + 1) % zoomImages.length]}
              prevSrc={zoomImages[(photoIndex + zoomImages.length - 1) % zoomImages.length]}
              onCloseRequest={() => {
                setisGalleryZoom(false);
              }}
              onMovePrevRequest={() => {
                setphotoIndex((photoIndex + zoomImages.length - 1) % zoomImages.length);
              }}
              onMoveNextRequest={() => {
                setphotoIndex((photoIndex + 1) % zoomImages.length);
              }}
            />
          ) : null}

          <Row>
            <Col lg={9}>
              <Card>
                <CardBody>
                  <CardTitle className="h4"></CardTitle>
                    <Slide>
                      {slideImages.map((slideImage, index)=> (
                        <div key={index}>
                          <div style={{ ...divStyle, 'backgroundImage': `url(${slideImage.url})` }}>
                            <span style={spanStyle}>{slideImage.caption}</span>
                          </div>
                        </div>
                      ))} 
                    </Slide>
                </CardBody>
              </Card>
            </Col>
            <Col lg={3}>
             <Card>
               <CardBody>

      <div {...getRootProps()} className={`dropzone ${isDragActive ? 'active' : ''}`}>
      <input {...getInputProps()} />
      {files.length > 0 ? (
        <div>
          {files.map((file, index) => (
            <div key={index} style={{ display: 'flex', alignItems: 'center' }}>
              <input
                type="checkbox"
                checked={file.checked}
                onChange={() => handleCheckboxChange(index)}
              />
              <img src={URL.createObjectURL(file)} alt={`Uploaded ${index + 1}`} />
              <button onClick={() => deleteFile(index)}>삭제</button>            
            </div>
          ))}
          <button onClick={deleteFiles}>선택된 항목 삭제</button>
        </div>
      ) : isDragActive ? (
        <p>여기에 파일을 드롭하세요!</p>
      ) : (
        <p>여기로 파일을 드래그 앤 드롭하세요.</p>
      )}
    </div>

    <div className="mt-2" style={{ display: 'grid', placeItems: 'center' }}>
      <Button
        className="btn btn-secondary me-1"
        onClick={() => {
              openFileDialog
            }}
            >
            이미지 업로드
      </Button> 
      <Button
            className="btn btn-secondary me-1"
            onClick={() => {
              handleButtonClick
            }}
            >
            이미지이동
      </Button> 
    </div>


              
                      
                </CardBody>
              </Card>
            </Col>
            
          </Row>
       
       <Row>
       <div>
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 1 }}>
          <img src="left-image.jpg" alt="Left Image" />
        </div>
        <div style={{ flex: 1, position: 'relative', left: isImageMoved ? '-100%' : 0 }}>
          <img src="right-image.jpg" alt="Right Image" />
        </div>
      </div>
      <button onClick={handleButtonClick}>이미지 이동</button>
      <button onClick={moveImages}>Move Images</button>
    </div>

       </Row>

<Row>
<div>
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 1 }}>
          <img
            src="left-image.jpg"
            alt="Left Image"
            style={{ transform: `translateX(${imagePositions[0]}px)` }}
          />
        </div>
        <div style={{ flex: 1 }}>
          <img
            src="right-image.jpg"
            alt="Right Image"
            style={{ transform: `translateX(${imagePositions[1]}px)` }}
          />
        </div>
      </div>
      <button onClick={handleButtonsClick}>이미지 이동</button>
      <button onClick={moveImages}>Move Images</button>
    </div>

</Row>
        </Container>
      </div>
    </React.Fragment>
  );
};

export default connect(
  null,
  {}
)(
  GoogleApiWrapper({
    apiKey: "AIzaSyAbvyBxmMbFhrzP9Z8moyYr6dCr-pzjhBE",
    LoadingContainer: LoadingContainer,
    v: "3",
  })(UiLightbox)
);
